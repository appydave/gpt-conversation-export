chrome.runtime.onInstalled.addListener(() => {
  console.log('ChatGPT Conversation Extractor installed');
});
